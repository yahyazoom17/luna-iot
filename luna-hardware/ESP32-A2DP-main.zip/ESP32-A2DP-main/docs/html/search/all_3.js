var searchData=
[
  ['dac_0',['Output to the Internal DAC',['../index.html#autotoc_md7',1,'']]],
  ['data_20from_20a_20a2ds_20data_20source_20with_20a_20callback_1',['Sending Data from a A2DS Data Source with a Callback',['../index.html#autotoc_md13',1,'']]],
  ['data_20stream_20with_20callbacks_2',['Accessing the Sink Data Stream with Callbacks',['../index.html#autotoc_md8',1,'']]],
  ['debounce_3',['debounce',['../class_bluetooth_a2_d_p_common.html#aa6601d3c57e37f77bfdd03a3ef6231e2',1,'BluetoothA2DPCommon']]],
  ['default_20pins_4',['A Simple I2S Example (A2DS Sink) using default Pins',['../index.html#autotoc_md4',1,'']]],
  ['defining_20pins_5',['Defining Pins',['../index.html#autotoc_md5',1,'']]],
  ['delay_5fms_6',['delay_ms',['../class_bluetooth_a2_d_p_common.html#a2302fff324e703c3906835f759e87307',1,'BluetoothA2DPCommon']]],
  ['dependencies_7',['dependencies',['../index.html#autotoc_md15',1,'Architecture / Dependencies'],['../index.html#autotoc_md2',1,'I2S API / Dependencies']]],
  ['digital_20sound_20processing_8',['Digital Sound Processing',['../index.html#autotoc_md16',1,'']]],
  ['disconnect_9',['disconnect',['../class_bluetooth_a2_d_p_common.html#ab63e627832d6377be32dd700130bf0d8',1,'BluetoothA2DPCommon']]],
  ['documentation_10',['Documentation',['../index.html#autotoc_md17',1,'']]]
];
