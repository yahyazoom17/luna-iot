var searchData=
[
  ['esp_5favrc_5frn_5fplay_5fstatus_5fchange_0',['ESP_AVRC_RN_PLAY_STATUS_CHANGE',['../group__a2dp.html#gab981cf845089ef19df871466126b6f14',1,'external_lists.h']]],
  ['event_1',['event',['../structbt__app__msg__t.html#a74f4561abb15d9ae98c3eefdd68de7c4',1,'bt_app_msg_t']]]
];
