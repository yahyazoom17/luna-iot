var searchData=
[
  ['the_20esp32_0',['A Simple Arduino Bluetooth Music Receiver and Sender for the ESP32',['../index.html',1,'']]]
];
